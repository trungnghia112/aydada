DROP TABLE IF EXISTS `#__hdflvaddgoogle`;

DROP TABLE IF EXISTS `#__hdflvplayerads`;

DROP TABLE IF EXISTS `#__hdflvplayerlanguage`;

DROP TABLE IF EXISTS `#__hdflvplayername`;

DROP TABLE IF EXISTS `#__hdflvplayersettings`;

DROP TABLE IF EXISTS `#__hdflvplayerupload`;
