Plugin Steps

1. Install the joomla_hdflvplayer_plugin.
2. In the plugin manager under extensions menu Hdflvplayer Plugin can be found.
3. Just publish it.
4. In any articles plugin can be used...
5. The attributes includes 

       * videoid
       * Height
       * Width
       * Autoplay
       * Playlist

6. Any one of the above attributes can be included...Mandatory is videoid
7. Below are the formats for plugin

        1.[hdplay videoid=1 height=300 width=700 playlist=true autoplay=true]
        2.[hdplay videoid=1]
        3.[hdplay videoid=2 height=300]  
        4.[hdplay videoid=4 width=700]   
        5.[hdplay videoid=3 autoplay=true]   
        6.[hdplay videoid=3 playlist=true]   

Different combinations can be used as mentioned above
