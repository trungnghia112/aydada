<?php
/*
Name: Wordpress Video Gallery
Plugin URI: http://www.apptha.com/category/extension/Wordpress/Video-Gallery
Description: Ajax playlist view file.
Version: 2.5
Author: Apptha
Author URI: http://www.apptha.com
License: GPL2
*/
?>