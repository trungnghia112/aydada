=== WORDPRESS VIDEO GALLERY ===
Contributors: hdflvplayer
Tags: Video Player plugin, video, flash player, flv player, WORDPRESS VIDEO GALLERY, flv player wordpress, hd flv player, youtube plugin, youtube Video Player, high definition Video Player, flash, play flv wordpress, player, Video Plugin, wp flv player, wp flv plugin, flv player 2009,  WORDPRESS VIDEO GALLERY, wp flv, wordpress flv plugin, wp hd flv player, flv player plugin, wordpress flv player
Requires at least: 2.8
Tested up to: 3.8
Stable tag: 2.5
Get the most exciting FLV player in the internet, designed and modified to suit your Wordpress websites.  Installing this Video Plugin is real easy and if you have any difficulty in installation, contact our Video Player support team and quickly resolve your issue.  You can either download this Video Plugin directly from our website or through Wordpress plugins page itself.  This WORDPRESS VIDEO GALLERY Version  has many advanced features that you cannot find elsewhere, such as that you can play youtube videos directly through this player, and it can also aptly be called as a youtube player.

== Description ==

Contus' Best WordPress Video Gallery Plugin has a whole set of utile features and options that make the product a versatile one. In addition to the quickly visible options such as recent Videos, popular Videos and featured Videos, the plugin also has the ability to control the number and order of these videos from back end.

Video Gallery Demo - http://www.apptha-demo.com/template/videostream/

Video Gallery Home Page - http://www.apptha.com/category/extension/Wordpress/Video-Gallery

FLV & H.264 encoded video including MP4, M4V, M4A, MOV, Mp4v, F4V, social networking comments from the gallery page (like for Facebook), provision to alter width, height, skin, theme, aspect ratio, volume, downloads etc. from the backend are few if the best features with this plugin. It also covers other regular and utile features which we could see in popular video sharing sites such as social media bookmark option (diggit, myspace, facebook, del.icio.us, spurl, furl, google), managing multiple playlists, views count for video and so forth.

* Option to modify the colors of player's skin icons, icons, text, etc.
* Supports HTML5 to play videos in iOS devices
* Facility to share your videos using social networking
* Option to monetize via IMA, pre-, mid-, post-roll video ads
* Easy to install the WordPress Video Gallery plugin
* Enthralls with responsive designing to help your visitors view your website on mobile
* Provides complete control on player through admin panel with a fantastic support
* This FLV Video plugin is capable to play FLV video & H.264 encoded video including MP3, MP4, M4V, M4A, MOV, Mp4v and F4V formats
* Supports RTL feature
* Supports Subtitle feature
* Supports Member video upload option
* Admin option to enable/disable Recent Videos, Popular Videos and Featured Videos
* Admin option to enable/disable Rating
* Easy to manage widgets like popular, featured, recent, related, video search, video categories.
* Flexible player size
* Ability to turn on/off and share volume functions
* Option to set playlist to be open/close by default
* Option to view videos on Full screen and also on 1X, 2X and 3X zoom capabilities
* Facility to design your own logo, right click copyright and edit logo position in admin once you purchase our package.
* Admin option to set the Logo (opacity control)
* Facility to enable/disable playlist, HD Default, playlist autoplay, autoplay.
* Option to combine player to play particular video or playlist using shortcodes in pages or posts.
* Offers complete control on number of columns and rows for the video thumb images.
* Individual sort order for each videos in the FLV player
* Multi- Language options for Tool tips on Player
* Facebook, Disqus, and default WP Commenting System for front-end users
* Facility to display the related videos on the side and center of the player. 
* Option to set up SEO friendly URL using two permalink options: default and postname
* Option to include a well-suited meta information
* Option to add RTMP based videos
* Option to add Viddler and Dailymotion videos
* Option to add Embed code based videos
* Rating option for the videos
* Language pack can be set on any preferred language
* Provides FFMPEG path in backend and generates timer for upload video.

== Installation ==

= Minimal Requirements =
* PHP: 5.x.x
* mySQL: 4.0, 4.1 or 5.x
* WordPress: 2.8 or newer

= Recommended Requirements =
* PHP: 5.2.x or newer
* mySQL: 5.x
* WordPress: 2.8 or newer

= Basic Installation =
1. Download the current version of the WORDPRESS VIDEO GALLERY plugin.
2. Go to your WordPress Admin Panel and click on Plugins >> Add New >> Upload
3. Choose the downloaded package and Install and Active the VIDEO GALLERY plugin.
4. That's it! You're done.

== Screenshots ==

1. **Video gallery(Front-end)**

2. **Manage Video** - Displays Uploaded videos and details about the plugin.

3. **Upload video file** - Here you can upload video using Upload Method

4. **Upload youtube URL** - Here you can upload video from YouTube

5. **Upload custom URL** - Here you can upload video via URL eg: http://www.domainname.com/foldername/video.mp4

6. **Upload RTMP Video** - You can add RTMP Streaming video

7. **Upload Embed Video** - You can add video using Embed code

8. **Gallery settings** - You can control Player and Plugin here.

9. **Manage video widgets** - We are providing 5 widgets. They are : Popular, Recent, Featured, Related videos, Video Search and Video Categories. You can assign the above mentioned widgets in any position of your template.

10. **Videos(recent,popular,feature, Video Categories)** - We are also displaying Popular, Recent, Featured, Related videos and Video Categories in content page under player.

== Other Notes ==

= To Add video =
1. Go to your WordPress Admin panel.
2. Click Video Gallery from left column >> All Videos >> Add Video.
3. Add a new Video using anyone of the options(YouTube URL , Upload File, Custom URL, RTMP)
4. Create and select the playlist from the Right column of the window to assign the video to the particular playlist.

= To change the global settings of the player =
1. Go to your WordPress Admin panel.
2. Click Video Gallery from left column >> Settings
3. Change the Plugin / Player settings as you wish.
4. You have options for Home page Recent,Popular,and Featured Videos enable,disable options with limit of rows and columns.

= To Display Side Widgets of the Player Like Recent,Popular,and Featured Videos
1. Go to your WordPress Admin panel.
2) Look for Apperance on the Left column and click Widgets Options.
3) Drag and Drop the options what you want to show in the right side bar.

= To See the Features in the user side
1. There is a Home Page for the videos to display and there Recent,Popular,and Featured Videos will show below the player.
2. Side Widgets also we have the same features with search videos options.

== Frequently Asked Questions ==
= How can i activate video gallery plugin? =
Download the zip file, install it and then activate the plugin.

= Where can I see the working demo of this Video Player or Video Plugin? =
You can see the demo of our WORDPRESS VIDEO GALLERY Version or Video Plugin in this link - http://www.apptha-demo.com/template/videostream/

= What are all the file formats HD FLV PLAYER can play? =
Our FLV player supports FLV & H.264 encoded video including MP3, MP4, M4V, M4A, MOV, Mp4v, F4V formats.

= How to contact the support / development team of our Video Player? =
You can contact us through,
Live Chat at http://www.apptha.com
Email: assist@apptha.com
Forums at http://www.apptha.com/forum

= Can I get the WORDPRESS VIDEO GALLERY plugin player customized to my needs? =
Yes, but there will be additional charges based on the request for customization has to be made by the requester.

= What is the advantage of using this Wordpress Video Gallery Plugin? =
To know more features and advantages of our player and this video plugin, visit this link - http://www.apptha.com/category/extension/Wordpress/Video-Gallery

= How to replace or remove the HD FLV Player demo logo from this WORDPRESS VIDEO GALLERY? =
For replacing or removing the demo logo from this FLV player, you need to purchase our commercial version of the player. You can find the Flash FLV player product over here at http://www.apptha.com/category/extension/Wordpress/Video-Gallery